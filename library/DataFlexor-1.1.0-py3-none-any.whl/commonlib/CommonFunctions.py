__AUTHOR__ = 'Mrinal Paul (mrinal.paul2@gilead.com)'

"""
   Module Name         :   Common Function Library
   Purpose             :   This module will provide commol function that can be used accross all the ETL script in Glue

   Last changed on     :   2023-05-02
   Last changed by     :   Mrinal Paul
   Reason for change   :   New Function added
"""
import boto3
from datetime import datetime
from botocore.exceptions import ClientError
import env.CommonConstants as CommonConstants

from awsglue.context import GlueContext
from pyspark.context import SparkContext
from pyspark.sql.functions import explode,explode_outer,regexp_replace,udf,lit,col,when
import base64
import json
from commonlib import patternValidator

sc = SparkContext.getOrCreate()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
logger = glueContext.get_logger()

class secretManager:
    def __init__(self,region_name='us-west-2'):
        # create S3 Client
        self.secret_client = boto3.client(
            service_name='secretsmanager',
            region_name=region_name
        )

    def getSecret(self, secret_name):
        try:
            logger.info("Fetching the details for the secret name %s" % secret_name)
            get_secret_value_response = self.secret_client.get_secret_value(
                SecretId=secret_name
            )
            logger.info("Fetched the Encrypted Secret from Secrets Manager for %s" % secret_name)
            # Decrypts secret using the associated KMS CMK.
            # Depending on whether the secret is a string or binary, one of these fields will be populated.
            if 'SecretString' in get_secret_value_response:
                secret = get_secret_value_response['SecretString']
                logger.info("Decrypted the Secret")
            else:
                secret = base64.b64decode(get_secret_value_response['SecretBinary'])
                logger.info("Decrypted the Secret")
            return json.loads(secret)
        except ClientError as exc:
            if exc.response['Error']['Code'] == 'DecryptionFailureException':
                # Secrets Manager can't decrypt the protected secret text using the provided KMS key.
                # Deal with the exception here, and/or rethrow at your discretion.
                raise exc
            elif exc.response['Error']['Code'] == 'InternalServiceErrorException':
                # An error occurred on the server side.
                # Deal with the exception here, and/or rethrow at your discretion.
                raise exc
            elif exc.response['Error']['Code'] == 'InvalidParameterException':
                # You provided an invalid value for a parameter.
                # Deal with the exception here, and/or rethrow at your discretion.
                raise exc
            elif exc.response['Error']['Code'] == 'InvalidRequestException':
                # You provided a parameter value that is not valid for the current state of the resource.
                # Deal with the exception here, and/or rethrow at your discretion.
                raise exc
            elif exc.response['Error']['Code'] == 'ResourceNotFoundException':
                # We can't find the resource that you asked for.
                # Deal with the exception here, and/or rethrow at your discretion.
                raise exc
            else:
                raise exc
        except Exception as exc:
            logger.exception(exc, exc_info=True)

class s3Functions:
    def __init__(self):
        # create S3 Client
        self.s3_client = boto3.client('s3')
        self.s3_client_Clean = boto3.resource('s3')
        self.s3_client_v2 = self.s3_client_Clean.meta.client

    def cleanUpS3(self,bucketName,prefix):
        # Delete all versions of objects once the file is moved to other S3 location
        logger.info("Clean up started")
        try:
            msg = "Clean Up Bucket Name: " + bucketName
            logger.info(msg)
            msg = "Clean Up Prefix: " + prefix
            logger.info(msg)
            bucket = self.s3_client_Clean.Bucket(bucketName)
            if prefix[-1] == '/':
                if prefix is None:
                    bucket.object_versions.delete()
                else:
                    bucket.object_versions.filter(Prefix=prefix).delete()
            else:
                for version in bucket.object_versions.all():
                    if version.object_key == prefix:
                        version.delete()
            logger.info("Clean up Completed")
            return True
        except Exception as e:
            message = "Error: " + e.__str__()
            logger.error(message)
            raise Exception(e.__str__())

    def createEmptyS3File(self,bucketName,key):
        try:
            self.s3_client.put_object(
                Bucket=bucketName,
                Key=key
            )
        except Exception as e:
            message = "Error: " + e.__str__()
            logger.error(message)
            raise Exception(e.__str__())

    def getFileContent(self,bucketName,key):
        logger.info("Strating function to get content of file: s3://"+bucketName+"/"+key)
        try:
            source_response = self.s3_client.get_object(Bucket=bucketName,Key=key)
            return source_response['Body']
        except Exception as e:
            message = "Error: " + e.__str__()
            logger.error(message)
            raise Exception(e.__str__())

    def listS3Files(self,bucketName,prefix):
        # This function will return file name as key in a S3 location
        try:
            result = self.s3_client.list_objects_v2(Bucket=bucketName, Prefix=prefix)
            return result.get('Contents')
        except Exception as e:
            message = "Error: " + e.__str__()
            logger.error(message)
            # raise Exception(e.__str__())
            return False

    def listS3Directories(self,bucketName,prefix):
        # This function will return file name as key in a S3 location
        try:
            logger.info("List files in S3 location s3://" + bucketName + "/" + prefix)
            result = self.s3_client.list_objects_v2(Bucket=bucketName, Prefix=prefix, Delimiter='/')
            prefixs = []
            result = result.get('CommonPrefixes')
            for p in result:
                prefixs.append(p.get('Prefix'))
                logger.info("Fetched Prefix " + p.get('Prefix'))
            logger.info(str(prefixs))
            return prefixs
        except Exception as e:
            message = "Error: " + e.__str__()
            logger.error(message)
            # raise Exception(e.__str__())
            return False

    def copyS3File(self,sourceBucket,sourceKey,destinationBucket,destinationKey):
        # Copy single file from one S3 location ot another
        try:
            copy_source = {'Bucket': sourceBucket, 'Key': sourceKey}
            logger.info(str(copy_source))
            self.s3_client.copy_object(Bucket = destinationBucket, CopySource = copy_source, Key = destinationKey)
            return True
        except Exception as e:
            message = "Error: " + e.__str__()
            logger.error(message)
            # raise Exception(e.__str__())
            return False
    def deleteS3File(self,bucketName,key):
        try:
            logger.info("Starting Delete File S3://" + bucketName + '/' + key)
            response = self.s3_client.delete_object(Bucket = bucketName, Key = key)
            if response:
                logger.info("Deleteted File S3://" + bucketName + '/' + key)
                # self.cleanUpS3(bucketName,key)
                return True
        except Exception as e:
            message = "Error: " + e.__str__()
            logger.error(message)
            # raise Exception(e.__str__())
            return False
    def moves3File(self,sourceBucket,sourceKey,destinationBucket,destinationKey):
        try:
            copy_response = self.copyS3File(sourceBucket,sourceKey,destinationBucket,destinationKey)
            if copy_response == False:
                message = "Unable to Copy file: s3://" + sourceBucket+"/"+sourceKey
                logger.error(message)
                return False
            else:
                response = self.deleteS3File(sourceBucket,sourceKey)
                if response == False:
                    logger.error("Unable to move file: s3://" + sourceBucket+"/"+sourceKey)
                    return False
                else:
                    logger.info("File to moved from s3://" + sourceBucket+"/"+sourceKey + " to s3://" + destinationBucket + "/" + destinationKey)
                    # self.cleanUpS3(sourceBucket,sourceKey)
                    return True
        except Exception as e:
            message = "Error: " + e.__str__()
            logger.error(message)
            return False
    def copyS3File_v2(self,sourceBucket,sourceKey,destinationBucket,destinationKey):
        # Copy single file from one S3 location ot another
        try:
            logger.info("Starting: Copy File greater then 5 GB")
            copy_source = {'Bucket': sourceBucket, 'Key': sourceKey}
            logger.info(str(copy_source))
            self.s3_client_v2.copy(copy_source,destinationBucket,destinationKey)
            return True
        except Exception as e:
            message = "Error: " + e.__str__()
            logger.error(message)
            # raise Exception(e.__str__())
            return False
    def moves3File_v2(self,sourceBucket,sourceKey,destinationBucket,destinationKey):
        try:
            logger.info("Starting: Moving Files greater then 5 GB")
            copy_response = self.copyS3File_v2(sourceBucket,sourceKey,destinationBucket,destinationKey)
            if copy_response == False:
                message = "Unable to Copy file: s3://" + sourceBucket+"/"+sourceKey
                logger.error(message)
                return False
            else:
                response = self.deleteS3File(sourceBucket,sourceKey)
                if response == False:
                    logger.error("Unable to move file: s3://" + sourceBucket+"/"+sourceKey)
                    return False
                else:
                    logger.info("File to moved from s3://" + sourceBucket+"/"+sourceKey + " to s3://" + destinationBucket + "/" + destinationKey)
                    # self.cleanUpS3(sourceBucket,sourceKey)
                    return True
        except Exception as e:
            message = "Error: " + e.__str__()
            logger.error(message)
            return False
    def deleteS3Directory(self,bucketName,prefix):
        # get list of files
        try:
            logger.info("Starting Delete Directory")
            response = self.listS3Files(bucketName,prefix)
            if (response == False) or (response == None):
                return False
            logger.info(str(response))
            for file in response:
                key = file['Key']
                message = "File to be Deleted: s3://"+bucketName+"/"+key
                logger.info(message)
                response = self.deleteS3File(bucketName,key)
                logger.info(str(response))
                if response == False:
                    logger.error("Unable to delete file: s3://" + bucketName+"/"+key)
                    return False
                else:
                    logger.info("Directory Deleted")
                    # raise Exception("Unable to delete file: s3://" + bucketName+"/"+key)
            return True
        except Exception as e:
            message = "Error: " + e.__str__()
            logger.error(message)
            # raise Exception(e.__str__())
            return False
    def copyS3Directory(self,sourceBucket,sourcePrefix,destinationBucket,destinationPrefix):
        # Copy S3 directory from one location to another
        try:
            response = self.listS3Files(sourceBucket,sourcePrefix)
            for file in response:
                sourceKey = file['Key']
                logger.info("Source Key: " + sourceKey)
                destinationKey = destinationPrefix + file['Key'].split("/")[-1]
                logger.info("Destination Key: " + destinationKey)
                copy_response = self.copyS3File(sourceBucket,sourceKey,destinationBucket,destinationKey)
                if copy_response == False:
                    message = "Unable to Copy file: s3://" + sourceBucket+"/"+sourceKey
                    logger.error(message)
                    return False
                    # raise Exception("Unable to Copy file: s3://" + sourceBucket+"/"+sourceKey)
                return True
        except Exception as e:
            message = "Error: " + e.__str__()
            logger.error(message)
            # raise Exception(e.__str__())
            return False
    def moveS3Directory(self,sourceBucket,sourcePrefix,destinationBucket,destinationPrefix):
        # Move S3 directory from one location to another
        logger.info("Starting Copying Files")
        logger.info("Source Lication: s3://" + sourceBucket + "/" + sourcePrefix)
        logger.info("Destination Lication: s3://" + destinationBucket + "/" + destinationPrefix)
        try:
            response = self.copyS3Directory(sourceBucket,sourcePrefix,destinationBucket,destinationPrefix)
            if response == True:
                # Delete the Source S3 location
                logger.info("Calling Function to Delete Directory: s3://" + sourceBucket+"/"+sourcePrefix)
                delete_response = self.deleteS3Directory(sourceBucket,sourcePrefix)
                if delete_response == True:
                    self.cleanUpS3(sourceBucket,sourcePrefix)
                    return True
                else:
                    return False
            else:
                message = "Unable to Move file: s3://" + sourceBucket+"/"+sourcePrefix
                logger.error(message)
                # raise Exception("Unable to Move file: s3://" + sourceBucket+"/"+sourcePrefix)
                return False
        except Exception as e:
            message = "Error: " + e.__str__()
            logger.error(message)
            # raise Exception(e.__str__())
            return False
    def getValidFileList(self, bucketName, prefix, filePattern, customPattern):
        try:
            msg = "File pattern is: " + filePattern
            logger.info(msg)
            msg = "Input Bucket is: " + prefix
            logger.info(msg)
            msg = "Input S3 Prefix is: " + filePattern
            logger.info(msg)
            s3FileList = self.listS3Files(bucketName,prefix)
            availableFiles = []
            if filePattern != None and filePattern != "":
                if customPattern.upper() == "Y":
                    customPatternFlag = True
                else:
                    customPatternFlag = False
                if (s3FileList == False) or (s3FileList == None):
                    msg = "No Files Available in Source S3 location"
                    logger.error(msg)
                    raise Exception(msg)
                patternValidatorObj = patternValidator()
                for file in s3FileList:
                    fileKey = file["Key"]
                    # Get File Name
                    finaleName = fileKey.split("/")[-1]
                    if finaleName != None or finaleName != "":
                        patternMatched = patternValidatorObj.patternValidator(source=finaleName, pattern=filePattern, customPattern = customPatternFlag)
                        if patternMatched == True:
                            availableFiles.append(finaleName)
            else:
                for file in s3FileList:
                    fileKey = file["Key"]
                    # Get File Name
                    finaleName = fileKey.split("/")[-1]
                    if finaleName != None and finaleName != "":
                        availableFiles.append(finaleName)
            return availableFiles
        except Exception as e:
            message = "Error: " + e.__str__()
            logger.error(message)
            raise Exception(e.__str__())
class cleanUp:
    def __init__(self):
        a = 1
    def ingestionCleanUp(self,bucketName,prefix):
        try:
            self.s3FunctionsObj = s3Functions()
            # Check if Directory exists
            dirCheck =  self.s3FunctionsObj.listS3Files(bucketName,prefix)
            if (dirCheck != None) and (dirCheck != False):
                logger.info("Starting Cleanup for Failed process")
                response = self.s3FunctionsObj.deleteS3Directory(bucketName,prefix)
                if response == True:
                    logger.info("Cleanup for Completed")
                    return True
                else:
                    message = "Cleanup for Failed Process Failed"
                    logger.info(message)
                    raise message
            else:
                return True
        except Exception as e:
            message = "Error: " + e.__str__()
            logger.error(message)
            return False
class Utils:
    def __init__(self):
        msg = "Initilizing Utils"
        logger.info(msg)

    def getPreviousHist(self, histTableName, histTablePartitionKey, stagingTableName='', stagingTablePartitionKey=[], columnsToBeDropped=[]):
        try:
            if histTableName == "" or histTableName == None:
                msg = "Hist Table Name is Mandatory"
                logger.error(msg)
                raise Exception(msg)
            if type(histTablePartitionKey) is not list:
                msg = "histTablePartitionKey should be a list"
                logger.error(msg)
                raise Exception(msg)
            if len(histTablePartitionKey) == 0:
                msg = "histTablePartitionKey is Empty"
                logger.error(msg)
                raise Exception(msg)
            # Prepare Hist Query
            histQuery = "SELECT * FROM " + histTableName + " WHERE "
            subQuery = ""
            for key in histTablePartitionKey:
                if subQuery == "":
                    subQuery = "{} = (SELECT max({}) FROM {})".format(key,key,histTableName)
                else:
                    subQuery = subQuery + " AND {} = (SELECT max({}) FROM {})".format(key,key,histTableName)
            histQuery = histQuery + subQuery
            try:
                msg = "Running Hist Query: " + histQuery
                logger.info(msg)
                histDf = spark.sql(histQuery)
            except:
                if stagingTableName == "" or stagingTableName == None:
                    msg = "Staging Table Name is Mandatory"
                    logger.error(msg)
                    raise Exception(msg)
                if type(stagingTablePartitionKey) is not list:
                    msg = "stagingTablePartitionKey should be a list"
                    logger.error(msg)
                    raise Exception(msg)
                if len(stagingTablePartitionKey) == 0:
                    msg = "stagingTablePartitionKey is Empty"
                    logger.error(msg)
                    raise Exception(msg)
                histQuery = "SELECT * FROM {} LIMIT 0".format(stagingTableName)
                msg = "Hist Table Doesn't Exists, getting table structure from Stagging Table! Running Query: " + histQuery
                logger.info(msg)
                histDf = spark.sql(histQuery)

            listAuditColumns = ["source_file_location","processed_time","execution_date","execution_cycle_id","source_file_name"]
            listAuditColumns = list(set(histTablePartitionKey + stagingTablePartitionKey + listAuditColumns + columnsToBeDropped))
            histDf = histDf.drop(*listAuditColumns)
            return histDf
        except Exception as e:
            message = "Error: an error occurred while getting Previous Hidt Data"
            logger.error(message)
            message = "Error: " + e.__str__()
            logger.error(message)
            raise e

    def getPreviousHistForDW(self, histTableName, histTablePartitionKey,columnsToBeDropped = []):
        try:
            if histTableName == "" or histTableName == None:
                msg = "Hist Table Name is Mandatory"
                logger.error(msg)
                raise Exception(msg)
            if type(histTablePartitionKey) is not list:
                msg = "histTablePartitionKey should be a list"
                logger.error(msg)
                raise Exception(msg)
            if len(histTablePartitionKey) == 0:
                msg = "histTablePartitionKey is Empty"
                logger.error(msg)
                raise Exception(msg)
            # Prepare Hist Query
            histQuery = "SELECT * FROM " + histTableName + " WHERE "
            subQuery = ""
            for key in histTablePartitionKey:
                if subQuery == "":
                    subQuery = "{} = (SELECT max({}) FROM {})".format(key,key,histTableName)
                else:
                    subQuery = subQuery + " AND {} = (SELECT max({}) FROM {})".format(key,key,histTableName)
            histQuery = histQuery + subQuery
            try:
                msg = "Running Hist Query: " + histQuery
                logger.info(msg)
                histDf = spark.sql(histQuery)
                histDf = histDf.drop(*histTablePartitionKey)
            except Exception as e:
                message = "Error: " + e.__str__()
                logger.error(message)
                raise e
            listAuditColumns = ["source_file_location","processed_time","execution_date","execution_cycle_id","source_file_name"]
            listAuditColumns = list(set(histTablePartitionKey + listAuditColumns + columnsToBeDropped))
            histDf = histDf.drop(*listAuditColumns)
            return histDf
        except Exception as e:
            message = "Error: an error occurred while getting Previous Hidt Data"
            logger.error(message)
            message = "Error: " + e.__str__()
            logger.error(message)
            raise e

    def getLatestStgData(self, stagingTableName, loadType='', stagingTablePartitionKey=[],columnsToBeDropped = []):
        try:
            if type(stagingTablePartitionKey) is not list:
                msg = "stagingTablePartitionKey should be a list"
                logger.error(msg)
                raise Exception(msg)
            if type(stagingTablePartitionKey) is not list:
                msg = "stagingTablePartitionKey should be a list"
                logger.error(msg)
                raise Exception(msg)
            if stagingTableName == "" or stagingTableName == None:
                msg = "Staginf Table Name is Mandatory"
                logger.error(msg)
                raise Exception(msg)
            # Prepare Staging Query
            # Custom list of cycles also need to be done in future
            match loadType.lower():
                case None:
                    try:
                        stgQuery = "SELECT * FROM {} WHERE ".format(stagingTableName)
                        subQuery = ""
                        for key in stagingTablePartitionKey:
                            if subQuery == "":
                                subQuery = "{} = (SELECT max({}) FROM {})".format(key,key,stagingTableName)
                            else:
                                subQuery = subQuery + " AND {} = (SELECT max({}) FROM {})".format(key,key,stagingTableName)
                        stgQuery = stgQuery + subQuery
                        msg = "Running Query: " + stgQuery
                        logger.info(msg)
                        stgDf = spark.sql(stgQuery)
                    except Exception as e:
                        message = "Error: " + e.__str__()
                        logger.error(message)
                        raise e
                case '':
                    try:
                        stgQuery = "SELECT * FROM {} WHERE ".format(stagingTableName)
                        subQuery = ""
                        for key in stagingTablePartitionKey:
                            if subQuery == "":
                                subQuery = "{} = (SELECT max({}) FROM {})".format(key,key,stagingTableName)
                            else:
                                subQuery = subQuery + " AND {} = (SELECT max({}) FROM {})".format(key,key,stagingTableName)
                        stgQuery = stgQuery + subQuery
                        msg = "Running Query: " + stgQuery
                        logger.info(msg)
                        stgDf = spark.sql(stgQuery)
                    except Exception as e:
                        message = "Error: " + e.__str__()
                        logger.error(message)
                        raise e
                case 'full':
                    stgQuery = "SELECT * FROM {}".format(stagingTableName)
                    msg = "Running Query: " + stgQuery
                    logger.info(msg)
                    stgDf = spark.sql(stgQuery)
                case 'latest_cycle':
                    columnNotFound = False
                    stgQueryDF = "SELECT * FROM {} WHERE execution_cycle_id = (select max(execution_cycle_id) from {})".format(stagingTableName,stagingTableName)
                    stgQueryCCF = "SELECT * FROM {} WHERE pt_cycle_id = (select max(pt_cycle_id) from {})".format(stagingTableName,stagingTableName)
                    try:
                        msg = "Running Query: " + stgQueryDF
                        logger.info(msg)
                        stgDf = spark.sql(stgQueryDF)
                    except Exception as e:
                        columnNotFound = True
                        msg = "execution_cycle_id Columns doesn't exists"
                        logger.info(msg)
                    try:
                        if columnNotFound == True:
                            msg = "Running Query: " + stgQueryCCF
                            logger.info(msg)
                            stgDf = spark.sql(stgQueryCCF)
                            columnNotFound = False
                    except Exception as e:
                        columnNotFound = True
                        msg = "pt_cycle_id Columns doesn't exists"
                        logger.info(msg)
                        try:
                            stgQuery = "SELECT * FROM {} WHERE ".format(stagingTableName)
                            subQuery = ""
                            for key in stagingTablePartitionKey:
                                if subQuery == "":
                                    subQuery = "{} = (SELECT max({}) FROM {})".format(key,key,stagingTableName)
                                else:
                                    subQuery = subQuery + " AND {} = (SELECT max({}) FROM {})".format(key,key,stagingTableName)
                            stgQuery = stgQuery + subQuery
                            msg = "Running Query: " + stgQuery
                            logger.info(msg)
                            stgDf = spark.sql(stgQuery)
                        except Exception as e:
                            message = "Error: " + e.__str__()
                            logger.error(message)
                            raise e
                case 'latest_date':
                    try:
                        stgQuery = "SELECT * FROM {} WHERE execution_date = (select max(execution_date) from {})".format(stagingTableName,stagingTableName)
                        msg = "Running Query: " + stgQuery
                        logger.info(msg)
                        stgDf = spark.sql(stgQuery)
                    except Exception as e:
                        msg = "execution_date Columns doesn't exists"
                        logger.info(msg)
                        try:
                            stgQuery = "SELECT * FROM {} WHERE ".format(stagingTableName)
                            subQuery = ""
                            for key in stagingTablePartitionKey:
                                if subQuery == "":
                                    subQuery = "{} = (SELECT max({}) FROM {})".format(key,key,stagingTableName)
                                else:
                                    subQuery = subQuery + " AND {} = (SELECT max({}) FROM {})".format(key,key,stagingTableName)
                            stgQuery = stgQuery + subQuery
                            msg = "Running Query: " + stgQuery
                            logger.info(msg)
                            stgDf = spark.sql(stgQuery)
                        except Exception as e:
                            message = "Error: " + e.__str__()
                            logger.error(message)
                            raise e
                case _:
                    msg = "Load Type not allowed"
                    logger.error(msg)
                    raise Exception(msg)
            # Prepare List of Audit Columns
            listAuditColumns = ["execution_date","execution_cycle_id","pt_batch_id","pt_cycle_id","pt_file_id","pt_data_dt"]
            listAuditColumns = list(set(stagingTablePartitionKey + listAuditColumns + columnsToBeDropped))
            stgDf = stgDf.drop(*listAuditColumns)
            return stgDf
        except Exception as e:
            message = "Error: " + e.__str__()
            logger.error(message)
            raise e
    def runDataLakeQuery(qyery):
        try:
            msg = "Executin Query in Data Lake: " + qyery
            logger.inof(msg)
            resultDf = spark.sql(qyery)
            msg = "Query Executed in Data Lake: " + qyery
            logger.inof(msg)
            return resultDf
        except Exception as e:
            message = "Error: " + e.__str__()
            logger.error(message)
            raise e