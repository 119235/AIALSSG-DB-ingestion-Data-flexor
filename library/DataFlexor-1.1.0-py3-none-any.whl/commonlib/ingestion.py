__AUTHOR__ = 'Mrinal Paul (mrinal.paul2@gilead.com)'

"""
   Module Name         :   Ingestion Module
   Purpose             :   This module is used for Ingestion file into data lake Glue Catalog Table

   Input               :   JSON File
   Output              :   Bool
   How to Invoke       :   call function ingestData(<S3 Prefix of JSON File for Dataset Parameters>)
   Last changed on     :   2023-05-02
   Last changed by     :   Mrinal Paul
   Reason for change   :   Ingestion Module Created
"""
import boto3
from datetime import datetime
from botocore.exceptions import ClientError
import env.CommonConstants as CommonConstants

from awsglue.context import GlueContext
from pyspark.context import SparkContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import base64
import json
import environmentParams as environmentParams
from commonlib import s3Functions,archive,reProcessIngestedFile
from commonetl import commonTransformation
from commonlib import GlueTable

sc = SparkContext.getOrCreate()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
logger = glueContext.get_logger()

class ingestion:
    def __init__(self):
        # create S3 Client
        self.s3Obj = s3Functions()
        self.executionDate = datetime.utcnow().strftime("%Y%m%d")
        self.cycleId = datetime.utcnow().strftime("%Y%m%d%H%M%S%f")
        self.processedTime = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
        self.commonTransformationObj = commonTransformation()
        self.logTableSchema = StructType([
                StructField("dataset_name", StringType(), True),
                StructField("application", StringType(), True),
                StructField("source_files", StringType(), True),
                StructField("static_file_pattern", StringType(), True),
                StructField("source_file_pattern", StringType(), True),
                StructField("file_type", StringType(), True),
                StructField("encoding", StringType(), True),
                StructField("escape", StringType(), True),
                StructField("multiline", StringType(), True),
                StructField("delimiter", StringType(), True),
                StructField("table_location", StringType(), True),
                StructField("target_schema", StringType(), True),
                StructField("target_table", StringType(), True),
                StructField("record_count", IntegerType(), True),
                StructField("execution_datetime", StringType(), True)
            ])
        self.logFileTableSchema = StructType([
                StructField("dataset_name", StringType(), True),
                StructField("file_name", StringType(), True),
                StructField("file_type", StringType(), True),
                StructField("record_count", IntegerType(), True),
                StructField("execution_datetime", StringType(), True)
            ])
    def updateGlueTable(self,sourceDataDf,targetSchema,targetTable,tableDescription,finalTableLocation,partitionKeys,partitionValues,archiveFlag=False):
        try:
            msg = "Partition Key: " + str(partitionKeys)
            logger.info(msg)
            msg = "Partition Value: " + str(partitionValues)
            logger.info(msg)
            # Create/Update Table
            columnList = self.commonTransformationObj.getColumnDataType(sourceDataDf)
            GlueTableObj = GlueTable(targetSchema,targetTable,tableDescription,columnList,finalTableLocation,partitionKeys,partitionValues)
            if archiveFlag == True:
                GlueTableObj.getAndDeletePartitions()
            # Load Partition
            status = GlueTableObj.loadGlueTable()
            if status == True:
                logger.info("Table "+targetTable+" loaded successfully")
                return True
            else:
                return False
        except Exception as e:
            msg = "Error: " + str(e.__str__())
            logger.error(msg)
            raise Exception(e.__str__())
    def updateIngestionLog(self,fileNameLog,rowCount):
        try:
            # Prepare Ingestion log Datafrate amd table
            ingestionLogSchema = environmentParams.STAGING_SCHEMA
            logTable = "ingestion_log_"+self.applicationName
            logTable = logTable.replace("-","_")

            ingestionLogList = [(self.datasetName,self.applicationName,fileNameLog,self.staticFilePattern,self.filePattern,self.fileType,self.encoding,self.escape,self.multiline,self.delimiter,self.tablePath,self.targetSchema,self.targetTable, rowCount, self.processedTime)]
            ingestionLogDf = spark.createDataFrame(ingestionLogList, schema=self.logTableSchema)
            # Write Log to S3 location
            logTablePath = "s3://" + environmentParams.CURATED_S3_BUCKET + "/" + self.applicationName + "/ingestion_log/" + logTable + "/"
            logTablePathFinal = logTablePath + "execution_date=" + self.executionDate + "/execution_cycle_id=" + str(self.cycleId) + "/"
            ingestionLogDf.replace("null","").write.mode("overwrite").option("multiline",True).option("escape","\"").option("self.encoding", "utf-8").parquet(logTablePathFinal)
            partitionKeys = [
                {
                    'name': "execution_date",
                    'data_type': "string"
                },
                {
                    'name': "execution_cycle_id",
                    'data_type': "string"
                }
            ]
            partitionValues = {
                "execution_date": str(self.executionDate),
                "execution_cycle_id": str(self.cycleId)
            }
            msg = "Original Partition Key: " + str(partitionKeys)
            logger.info(msg)
            msg = "Original Partition Value: " + str(partitionValues)
            logger.info(msg)
            self.updateGlueTable(ingestionLogDf,ingestionLogSchema,logTable,'',logTablePath,partitionKeys,partitionValues)
            msg = "Updated Log Table: " + logTable
            logger.info(msg)
        except Exception as e:
            msg = "Error: " + str(e.__str__())
            logger.error(msg)
            raise Exception(e.__str__())
    def updateFileLog(self,fileName,rowCount):
        try:
            # Prepare Ingestion log Datafrate amd table
            ingestionLogSchema = environmentParams.STAGING_SCHEMA
            fileLogTable = "file_log_"+self.applicationName
            fileLogTable = fileLogTable.replace("-","_")

            fileLogList = [(self.datasetName,fileName,self.fileType, rowCount, datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S"))]
            ingestionLogDf = spark.createDataFrame(fileLogList, schema=self.logFileTableSchema)
            # Write Log to S3 location
            fileLogTablePath = "s3://" + environmentParams.CURATED_S3_BUCKET + "/" + self.applicationName + "/file_log/" + fileLogTable + "/"
            fileLogTablePathFinal = fileLogTablePath + "execution_date=" + self.executionDate + "/execution_cycle_id=" + str(self.cycleId) + "/" + "source_file_name=" + fileName + "/"
            ingestionLogDf.replace("null","").write.mode("overwrite").option("multiline",True).option("escape","\"").option("self.encoding", "utf-8").parquet(fileLogTablePathFinal)
            partitionKeys = [
                {
                    'name': "execution_date",
                    'data_type': "string"
                },
                {
                    'name': "execution_cycle_id",
                    'data_type': "string"
                },
                {
                    'name': "source_file_name",
                    'data_type': "string"
                }
            ]
            partitionValues = {
                "execution_date": str(self.executionDate),
                "execution_cycle_id": str(self.cycleId),
                "source_file_name": str(fileName)
            }
            self.updateGlueTable(ingestionLogDf,ingestionLogSchema,fileLogTable,'',fileLogTablePath,partitionKeys,partitionValues)
            msg = "Updated Log Table: " + fileLogTable
            logger.info(msg)
            return True
        except Exception as e:
            msg = "Error: " + str(e.__str__())
            logger.error(msg)
            raise Exception(e.__str__())
    def createStagingtablePath(self,sourceFileLocation):
        try:
            sourceFileName = sourceFileLocation.split("/")[-1]
            partitionKeys = [
                {
                    'name': "execution_date",
                    'data_type': "string"
                },
                {
                    'name': "execution_cycle_id",
                    'data_type': "string"
                },
                {
                    'name': "source_file_name",
                    'data_type': "string"
                }
            ]
            partitionValues = {
                "execution_date": str(self.executionDate),
                "execution_cycle_id": str(self.cycleId),
                "source_file_name": str(sourceFileName)
            }
            tableSubPath = ""
            for k in partitionKeys:
                if tableSubPath == "":
                    tableSubPath = k["name"] + "=" + partitionValues[k["name"]] + "/"
                else:
                    tableSubPath = tableSubPath + k["name"] + "=" + partitionValues[k["name"]] + "/"
            return tableSubPath,partitionKeys,partitionValues
        except Exception as e:
            msg = "Error: " + str(e.__str__())
            logger.error(msg)
            raise Exception(e.__str__())
    def loadStagingTable(self,fileType,sourceFileLocation,option):
        try:
            # Prepare Final S3 Location
            tableSubPath,partitionKeys,partitionValues = self.createStagingtablePath(sourceFileLocation)
            finalTableLocation = self.tablePath + tableSubPath
            sourceFileLocation = "s3://" + self.sourceS3Bucket + "/" + sourceFileLocation
            msg = "Started Loading File: " + sourceFileLocation
            logger.info(msg)
            sourceFileName = sourceFileLocation.split("/")[-1]
            match fileType:
                case "csv":
                    sourceDataDf = spark.read.format("csv").options(**option).load(sourceFileLocation)
                case "txt":
                    sourceDataDf = spark.read.format("csv").options(**option).load(sourceFileLocation)
                case "parquet":
                    sourceDataDf = spark.read.format("parquet").options(**option).load(sourceFileLocation)
            # Write Source DF to S3 Target Location
            sourceDataDf = sourceDataDf.withColumn("source_file_location",lit(sourceFileLocation)).withColumn("processed_time",lit(self.processedTime))
            sourceDataDf = self.commonTransformationObj.hederNameStandardization(sourceDataDf)
            sourceDataDf.replace("null","").write.mode("overwrite").option("multiline",True).option("escape","\"").option("self.encoding", "utf-8").parquet(finalTableLocation)
            if self.loadType == "FULL" and self.archiveFlag == "Y":
                archiveFlag = True
            else:
                archiveFlag = False
            self.updateGlueTable(sourceDataDf,self.targetSchema,self.targetTable,'',self.tablePath,partitionKeys,partitionValues,archiveFlag)
            msg = "Loaded File: " + sourceFileLocation
            logger.info(msg)
            count = sourceDataDf.count()
            self.updateFileLog(sourceFileName,count)
            msg = "Total Record Loaded from file " + sourceFileName + " is: " + str(count)
            logger.info(msg)
            return count
        except Exception as e:
            msg = "Error: " + str(e.__str__())
            logger.error(msg)
            raise Exception(e.__str__())
    def ingestData(self,datasetMasterKey):
        try:
            # Read Ingestion Object Json Config
            if datasetMasterKey.endswith("/"):
                msg = "datasetMasterKey should not be directory"
                logger.error(msg)
                raise Exception(msg)
            if datasetMasterKey.startswith('s3://'):
                datasetMasterKey = datasetMasterKey.lstrip("s3://").split("/")
                datasetMasterBucket = datasetMasterKey[0]
                datasetMasterKey = "/".join(datasetMasterKey[1:])
            else:
                datasetMasterBucket = environmentParams.PLATFORM_ARTIFACTS_S3_BUCKET
                datasetMasterKey = datasetMasterKey.lstrip("/").split("/")
                if datasetMasterKey[0] == environmentParams.APPLICATION_NAME:
                    datasetMasterKey = "/".join(datasetMasterKey)
                else:
                    datasetMasterKey = environmentParams.APPLICATION_NAME + "/" + "/".join(datasetMasterKey)
            try:
                datasetMaster = self.s3Obj.getFileContent(datasetMasterBucket,datasetMasterKey).read().decode('utf-8')
                datasetMaster = json.loads(datasetMaster)
            except Exception as e:
                msg = "Error: " + str(e.__str__()) + "s3://" + datasetMasterBucket + "/" + datasetMasterKey
                logger.error(msg)
                raise Exception(e.__str__())

            option = {}
            self.datasetName = datasetMaster.get("dataset_name")
            active = datasetMaster.get("active")
            if active.upper() == "N":
                msg = "Skipping the Process as The Dataset is not Active for Ingestion"
                logger.warn(msg)
                return True

            self.datasetName = datasetMaster.get("dataset_name")
            self.applicationName = environmentParams.APPLICATION_NAME.lower()
            # get source bucket
            match datasetMaster.get("source_bucket").upper():
                case "RAW_S3_BUCKET":
                    self.sourceS3Bucket = environmentParams.RAW_S3_BUCKET
                case "SANDBOX_S3_BUCKET":
                    self.sourceS3Bucket = environmentParams.SANDBOX_S3_BUCKET
                case "PROCESSED_S3_BUCKET":
                    self.sourceS3Bucket = environmentParams.PROCESSED_S3_BUCKET
                case "CURATED_S3_BUCKET":
                    self.sourceS3Bucket = environmentParams.CURATED_S3_BUCKET
                case _:
                    self.sourceS3Bucket = datasetMaster.get("source_bucket").lstrip("s3://").rstrip("/")
            # get source prefix
            sourcePrefix = datasetMaster.get("source_prefix").strip("/") + "/"
            # get pettern
            self.staticFilePattern = datasetMaster.get("static_file_pattern")
            self.filePattern = datasetMaster.get("source_file_pattern")

            sourceFileList = []
            if self.filePattern == None or self.filePattern == "":
                # If FileName Pattern is Blank or NUll process All thh files
                sourceFileList = self.s3Obj.getValidFileList(self.sourceS3Bucket, sourcePrefix, "", "N")
            elif self.staticFilePattern.upper() == "Y":
                sourceFileList.append(self.filePattern)
            else:
                # match patter and get valid file list
                try:
                    customPattern = datasetMaster.get("custom_pattern")
                except Exception as e:
                    customPattern = "N"
                    msg = "Using Default Pattern"
                    logger.info(msg)
                sourceFileList = self.s3Obj.getValidFileList(self.sourceS3Bucket, sourcePrefix, self.filePattern, customPattern)
            # Get File Details
            self.fileType = datasetMaster.get("file_type")

            try:
                self.encoding = datasetMaster.get("self.encoding")
                if self.encoding != None and self.encoding != "":
                    option.update({"self.encoding": self.encoding})
            except Exception as e:
                msg = "Using Default Encoding"
                logger.info(msg)

            try:
                self.escape = datasetMaster.get("escape")
                if self.escape != None and self.escape != "":
                    option.update({"escape": self.escape})
            except Exception as e:
                msg = "By Default Escape Character is not Applied"
                logger.info(msg)

            try:
                self.multiline = datasetMaster.get("multiline").lower()
                if self.multiline == "true":
                    option.update({"multiline": self.multiline})
            except Exception as e:
                msg = "By Default Multiline Option is Set to False"
                logger.info(msg)

            # try:
            #     self.dropMalformedRecords = datasetMaster.get("drop_malformed_records").upper()
            #     if self.dropMalformedRecords == "Y" and self.fileType in ["csv","txt"]:
            #         option.update({"mode": self.dropMalformedRecords})
            # except Exception as e:
            #     msg = "Drop Malformed Records is Set to N"
            #     logger.info(msg)

            match datasetMaster.get("target_bucket").upper():
                case "RAW_S3_BUCKET":
                    self.targetBucket = environmentParams.RAW_S3_BUCKET
                case "SANDBOX_S3_BUCKET":
                    self.targetBucket = environmentParams.SANDBOX_S3_BUCKET
                case "PROCESSED_S3_BUCKET":
                    self.targetBucket = environmentParams.PROCESSED_S3_BUCKET
                case "CURATED_S3_BUCKET":
                    self.targetBucket = environmentParams.CURATED_S3_BUCKET
                case _:
                    self.targetBucket = datasetMaster.get("target_bucket").lstrip("s3://").rstrip("/")
            self.targetPrefix = datasetMaster.get("target_prefix").strip("/") + "/"
            self.tablePath = "s3://" + self.targetBucket + "/" + self.targetPrefix
            msg = "Table Path: " + self.tablePath
            logger.info(msg)
            self.targetTable = datasetMaster.get("target_table").upper()
            if len(self.targetTable) > 40:
                msg = "Maximum Length of Table Name allowed is 40 Character"
                logger.info(msg)
                raise Exception(msg)
            match datasetMaster.get("target_schema").upper():
                case "STAGING_SCHEMA":
                    self.targetSchema = environmentParams.STAGING_SCHEMA
                case "PROCESSED_SCHEMA":
                    self.targetSchema = environmentParams.PROCESSED_SCHEMA
                case "REPORTING_SCHEMA":
                    self.targetSchema = environmentParams.REPORTING_SCHEMA
                case "PUBLISH_SCHEMA":
                    self.targetSchema = environmentParams.PUBLISH_SCHEMA
                case _:
                    self.targetSchema = datasetMaster.get("target_schema")
            self.loadType = datasetMaster.get("load_type").upper()
            try:
                self.archiveFlag = datasetMaster.get("archive").upper()
            except Exception as e:
                self.archiveFlag = "N"
            if self.staticFilePattern.upper() == "N":
                try:
                    # Lest List of Files Needs to be reprocessed
                    self.reProcessMasterFile = datasetMaster.get("reprocess_master_file_s3_key")
                    if self.reProcessMasterFile == None or self.reProcessMasterFile == "":
                        logger.error("Re-Process Master File S3 Key is Blank")
                    if self.reProcessMasterFile.endswith('/'):
                        msg = "Error: Re-Process Master File S3 Key Should be File not Directory"
                        logger.error(msg)
                        raise Exception(msg)
                    if self.reProcessMasterFile.startswith('s3://'):
                        self.reProcessMasterFile = "/".join(self.reProcessMasterFile.lstrip("s3://").split("/")[1:])
                    else:
                        self.reProcessMasterFile = self.reProcessMasterFile.lstrip("/").split("/")
                        if self.reProcessMasterFile[0] == environmentParams.APPLICATION_NAME:
                            self.reProcessMasterFile = "/".join(self.reProcessMasterFile)
                        else:
                            self.reProcessMasterFile = environmentParams.APPLICATION_NAME + "/" +"/".join(self.reProcessMasterFile)

                except Exception as e:
                    logger.error("Re-Process Master File S3 Key not Available")
                    self.reProcessMasterFile = ""
                # Clean Up for Reprocessing
                if self.reProcessMasterFile != "":
                    reprocessObj = reProcessIngestedFile()
                    listOfFileToBeReProcessed = reprocessObj.prepareForReProcessing(self.reProcessMasterFile,self.datasetName,self.targetSchema,self.targetTable,self.targetBucket,self.targetPrefix,self.executionDate)
                else:
                    listOfFileToBeReProcessed = []
                # Get List of Already Processed File List
                try:
                    fileLogTable = environmentParams.STAGING_SCHEMA + ".file_log_" + self.applicationName
                    fileLogTable = fileLogTable.replace("-","_")
                    processedFilesDf = spark.sql("SELECT DISTINCT file_name from {} WHERE dataset_name = '{}'".format(fileLogTable, self.datasetName))
                    processedFiles = [str(row.file_name) for row in processedFilesDf.select("file_name").collect()]
                except Exception as e:
                    processedFiles = []
                    msg = "Log Table Not Available"
                    logger.info(msg)

                msg = "Files available in Source Location: " + str(sourceFileList)
                logger.info(msg)
                msg = "Files Already Processed: " + str(processedFiles)
                logger.info(msg)
                # Prepare List of Files needs to processed in the run
                if len(listOfFileToBeReProcessed) > 0:
                    msg = "Files to be Re-Processed: " + ", ".join(listOfFileToBeReProcessed)
                    logger.info(msg)
                    processedFiles = list(set(processedFiles) - set(listOfFileToBeReProcessed))
                sourceFileList = list(set(sourceFileList) - set(processedFiles))
                msg = "Files Available for Processing: " + str(sourceFileList)
                logger.info(msg)
            if len(sourceFileList) == 0:
                # msg = "Skipping the Process as No File Available for Processing"
                # logger.warn(msg)
                # return True
                msg = "No Failes Available for Processing"
                logger.error(msg)
                raise Exception(msg)
            # Ingest File
            fileNameLog = []
            rowCount = 0
            match self.fileType.lower():
                case "csv":
                    try:
                        self.delimiter = datasetMaster.get("delimiter")
                        if self.delimiter != None and self.delimiter != "":
                            option.update({"delimiter": self.delimiter})
                        else:
                            option.update({"delimiter": ","})
                    except Exception as e:
                        option.update({"delimiter": ","})
                        msg = "Using Default Delimiter for CSV file (,)"
                        logger.info(msg)

                    try:
                        self.header = datasetMaster.get("header").upper()
                    except Exception as e:
                        msg = "Header is mendatory for file type: " + self.fileType
                        logger.info(msg)
                        raise Exception(msg)
                    if self.header == "TRUE":
                        self.header = "true"
                    else:
                        self.header = "false"
                        msg = "the value of header 'false' will be supported in the next release"
                        raise Exception(msg)
                    option.update({"header": self.header})
                    for sourcefile in sourceFileList:
                        sourceFileLocation = sourcePrefix + sourcefile
                        count = self.loadStagingTable(self.fileType,sourceFileLocation,option)
                        fileNameLog.append(sourcefile)
                        rowCount = rowCount + count
                case "txt":
                    try:
                        self.delimiter = datasetMaster.get("delimiter")
                        if self.delimiter != None and self.delimiter != "":
                            option.update({"delimiter": self.delimiter})
                        else:
                            msg = "Delimiter is Mandatory for file type: " + self.fileType
                            logger.error(msg)
                            raise Exception(msg)
                    except Exception as e:
                        msg = "Delimiter is Mandatory for file type: " + self.fileType
                        logger.error(msg)
                        raise Exception(msg)
                    try:
                        self.header = datasetMaster.get("header").upper()
                    except Exception as e:
                        msg = "Header is mendatory for file type: " + self.fileType
                        logger.info(msg)
                        raise Exception(msg)
                    if self.header == "TRUE":
                        self.header = "true"
                    else:
                        self.header = "false"
                        msg = "the value of header 'false' will be supported in the next release"
                        raise Exception(msg)
                    option.update({"header": self.header})
                    for sourcefile in sourceFileList:
                        sourceFileLocation = sourcePrefix + sourcefile
                        count = self.loadStagingTable(self.fileType,sourceFileLocation,option)
                        fileNameLog.append(sourcefile)
                        rowCount = rowCount + count
                case "parquet":
                    for sourcefile in sourceFileList:
                        sourceFileLocation = sourcePrefix + sourcefile
                        count = self.loadStagingTable(self.fileType,sourceFileLocation,option)
                        fileNameLog.append(sourcefile)
                        rowCount = rowCount + count
                case "json":
                    msg = "JSON File is not Yes Supported"
                    logger.error(msg)
                    raise Exception(msg)
                case _:
                    msg = "File Type "+self.fileType+" not Supported for Ingestion"
                    logger.error(msg)
                    raise Exception(msg)
            msg = "Updated Staging Table: " + self.targetTable
            logger.info(msg)
            self.updateIngestionLog(fileNameLog,rowCount)
            # Start Archival Process
            if self.loadType in ["FULL", "ROLLING"] and self.archiveFlag == "Y":
                archiveBucket = datasetMaster.get("archive_location_bucket")
                match archiveBucket.upper():
                    case "RAW_S3_BUCKET":
                        archiveBucket = environmentParams.RAW_S3_BUCKET
                    case "SANDBOX_S3_BUCKET":
                        archiveBucket = environmentParams.SANDBOX_S3_BUCKET
                    case "PROCESSED_S3_BUCKET":
                        archiveBucket = environmentParams.PROCESSED_S3_BUCKET
                    case "CURATED_S3_BUCKET":
                        archiveBucket = environmentParams.CURATED_S3_BUCKET
                    case _:
                        archiveBucket = datasetMaster.get("source_bucket").lstrip("s3://").rstrip("/")
                archivePrefix = datasetMaster.get("archive_location_prefix")
                archiveObj = archive()
                archiveObj.archiveStaging(self.targetBucket,self.targetPrefix+"execution_date="+self.executionDate+"/",self.cycleId,archiveBucket,archivePrefix)
                msg = "Archived Previous Run Data"
                logger.info(msg)
            else:
                msg = "Skipping Archival Process for " + self.targetTable + " as the load type is not FULL"
                logger.info(msg)
        except Exception as e:
            logger.error("Error: " + e.__str__())
            raise Exception(e.__str__())