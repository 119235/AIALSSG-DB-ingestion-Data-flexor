__AUTHOR__ = 'Mrinal Paul (mrinal.paul2@gilead.com)'

"""
   Module Name         :   Publish Table Clean-Up Module
   Purpose             :   This Module is used for Cleaning Previous Run's files from Publish Table S3 Location

   Last changed on     :   2023-05-02
   Last changed by     :   Mrinal Paul
   Reason for change   :   New Function added
"""
import boto3
from datetime import datetime
from botocore.exceptions import ClientError
import env.CommonConstants as CommonConstants

from awsglue.context import GlueContext
from pyspark.context import SparkContext
from pyspark.sql.functions import explode,explode_outer,regexp_replace,udf,lit,col,when
import base64
import json
from commonlib import s3Functions

sc = SparkContext.getOrCreate()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
logger = glueContext.get_logger()

class publishCleanup:
    def __init__(self):
        self.s3Obj = s3Functions()

    def publishCleanup(self,bucket,prefix,cycleId):
        try:
            prefixes = self.s3Obj.listS3Directories(bucket,prefix)
            for prefix in prefixes:
                if cycleId not in prefix:
                    cleanUpResponse = self.s3Obj.cleanUpS3(bucket,prefix)
                    if cleanUpResponse == False:
                        msg = "Unable to Clean Sublish Location: s3://" + bucket + "/" + prefix
                        logger.error(msg)
        except Exception as e:
            logger.error("Error: " + e.__str__())
            raise Exception(e.__str__())