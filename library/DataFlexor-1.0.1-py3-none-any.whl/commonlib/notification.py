"""
Author              : Mrinal Paul
Owner               : Medical Affairs DevOps
Date                : 2023-05-09
Doc_Type            : Tech Products
Description         : This utility is used for sending Notification emails using AWS SES service. Default AWS
                      Region for SES is "us-west-2" if not defind by calling script.
Pre_requisites      :
Inputs              :
Outputs             :
Example             :
Config_file         : NA
Last changed on     : 2023-05-09
Last changed by     : Mrinal Paul
Reason for change   : New Module
"""

import os
import argparse
import json
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication
# import boto.ses
import boto3
import ast
from awsglue.context import GlueContext
from pyspark.context import SparkContext
from pyspark.sql.functions import explode,explode_outer,regexp_replace,udf,lit,col,when
import base64
import json


sc = SparkContext.getOrCreate()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
logger = glueContext.get_logger()

STATUS_FAILED = "FAILED"
STATUS_SUCCESS = "SUCCESS"
STATUS_KEY = "status"
ERROR_KEY = "error"
RESULT_KEY = "result"
MIME_TYPE = "html"
EMAIL_SUBJECT_KEY = "Subject"
TO_KEY = "To"
JSON_FILE_PATH_KEY = "json_file_path"
SES_REGION_KEY = "SES_REGION_KEY"
SUBJECT_KEY = "SUBJECT_KEY"
SENDER_KEY = "SENDER_KEY"
RECIPIENT_LIST_KEY = "RECIPIENT_LIST_KEY"
EMAIL_BODY_KEY = "EMAIL_BODY_KEY"
EMAIL_TEMPLATE_KEY = "EMAIL_TEMPLATE_KEY"
PARAM_REPLACE_KEY = "PARAM_REPLACE_KEY"
SOURCE_ARN = "SES_SRC_ARN"
RETURN_ARN = "SES_RTRN_ARN"
APPROVE_DATASET_EMAIL_TEMPLATE_KEY = "APPROVE_DATASET_EMAIL_TEMPLATE_KEY"
APPROVE_RULE_EMAIL_TEMPLATE_KEY = "APPROVE_RULE_EMAIL_TEMPLATE_KEY"
CREATE_RULE_EMAIL_TEMPLATE_KEY = "CREATE_RULE_EMAIL_TEMPLATE_KEY"
DENY_RULE_EMAIL_TEMPLATE_KEY = "DENY_RULE_EMAIL_TEMPLATE_KEY"
COMPLETE_RULE_EMAIL_TEMPLATE_KEY = "COMPLETE_RULE_EMAIL_TEMPLATE_KEY"
APPROVE_DATASET_EMAIL_SUBJECT_KEY = "APPROVE_DATASET_EMAIL_SUBJECT_KEY"
APPROVE_RULE_EMAIL_SUBJECT_KEY = "APPROVE_RULE_EMAIL_SUBJECT_KEY"
CREATE_RULE_EMAIL_SUBJECT_KEY = "CREATE_RULE_EMAIL_SUBJECT_KEY"
DENY_RULE_EMAIL_SUBJECT_KEY = "DENY_RULE_EMAIL_SUBJECT_KEY"
COMPLETE_RULE_EMAIL_SUBJECT_KEY = "COMPLETE_RULE_EMAIL_SUBJECT_KEY"
APPROVE_DQM_EMAIL_TEMPLATE_KEY = "APPROVE_DQM_EMAIL_TEMPLATE_KEY"
DENY_DQM_EMAIL_TEMPLATE_KEY = "DENY_DQM_EMAIL_TEMPLATE_KEY"
COMPLETE_DQM_EMAIL_TEMPLATE_KEY = "COMPLETE_DQM_EMAIL_TEMPLATE_KEY"
APPROVE_DQM_EMAIL_SUBJECT_KEY = "APPROVE_DQM_EMAIL_SUBJECT_KEY"
DENY_DQM_EMAIL_SUBJECT_KEY = "DENY_DQM_EMAIL_SUBJECT_KEY"
COMPLETE_DQM_EMAIL_SUBJECT_KEY = "COMPLETE_DQM_EMAIL_SUBJECT_KEY"

CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))

service_directory_path = os.path.dirname(os.path.abspath(__file__))
template_dir_path = os.path.abspath(os.path.join(service_directory_path, "../../templates/"))

# All module level constants are declared here
FAILED_STATUS = {STATUS_KEY:
                     STATUS_FAILED,
                 ERROR_KEY: "",
                 RESULT_KEY: ""}
SUCCESS_STATUS = {STATUS_KEY:
                      STATUS_SUCCESS,
                  ERROR_KEY: "",
                  RESULT_KEY: ""}


class notification:
    def __init__(self,sesRegion='us-west-2'):
        self.sesRegion = sesRegion
        self.sesConnection = boto3.client('sesv2', region_name=self.sesRegion)

    def emailValidator(self, emailSubject, emailBody, emailSender, emailSenderArn,feedbackForwardingEmailAddress, feedbackForwardingEmailAddressIdentityArn, emailRecipientList, replyToEmail):
        """
        Purpose   :   This function will validate all the inputs
        Input     :
        Output    :   Returns True if all the inputs are validated else raises Exception
        """
        if emailSubject is None or emailSubject == "":
            statusMessage = "Email Subject cannot be Empty for Sending Email Notifications"
            raise Exception(statusMessage)

        if emailSender is None or emailSender == "":
            statusMessage = "Email Sender cannot be Empty for Sending Email Notifications"
            raise Exception(statusMessage)

        if emailSenderArn is None or emailSenderArn == "":
            statusMessage = "Email Sender ARN cannot be Empty for Sending Email Notifications"
            raise Exception(statusMessage)

        if type(replyToEmail) != list or len(replyToEmail) == 0:
            statusMessage = "Reply to Email shpuld be in Python List form for Sending Email Notifications"
            raise Exception(statusMessage)

        if feedbackForwardingEmailAddress is None or feedbackForwardingEmailAddress == "":
            statusMessage = "Email Feedback Address cannot be Empty for Sending Email Notifications"
            raise Exception(feedbackForwardingEmailAddress)
        elif type(feedbackForwardingEmailAddress) != str:
            statusMessage = "Email Feedback Address should be string for Sending Email Notifications"
            raise Exception(statusMessage)

        if feedbackForwardingEmailAddressIdentityArn is None or feedbackForwardingEmailAddressIdentityArn == "":
            statusMessage = "Email Feedback Address cannot be Empty for Sending Email Notifications"
            raise Exception(statusMessage)
        elif type(feedbackForwardingEmailAddressIdentityArn) != str:
            statusMessage = "Email Feedback Address should be string for Sending Email Notifications"
            raise Exception(statusMessage)

        if not emailRecipientList or type(emailRecipientList) != list:
            statusMessage = "Email Recipient List in Python List form for Sending Email Notifications"
            raise Exception(statusMessage)
        elif len(emailRecipientList) == 0:
            statusMessage = "Email Recipient List cannot be Empty for Sending Email Notifications"
            raise Exception(statusMessage)

        if emailBody is None or emailBody == "":
            statusMessage = "Email Boby cannot be Empty for Sending Email Notifications"
            raise Exception(statusMessage)
        return True

    def sendEmail(self, emailSubject, emailBody, emailSender,emailSenderArn, feedbackForwardingEmailAddress, feedbackForwardingEmailAddressIdentityArn, emailRecipientList, ccEmailRecipientList=None,bccEmailRecipientList=None, replyToEmail=['no_reply@gilead.com']):
        """Function to send Email"""
        try:
            if self.emailValidator(emailSubject, emailBody, emailSender, emailSenderArn,feedbackForwardingEmailAddress, feedbackForwardingEmailAddressIdentityArn, emailRecipientList,replyToEmail):
                logger.info("Email Inputs Validated successfully" + str(emailRecipientList))
                emailSubject = emailSubject.replace("\n", " ").replace("\t", " ").replace("\r", " ")

                response = self.sesConnection.send_email(
                    FromEmailAddress=emailSender,
                    FromEmailAddressIdentityArn=emailSenderArn,
                    Destination={
                        'ToAddresses': emailRecipientList,
                        'CcAddresses': ccEmailRecipientList,
                        'BccAddresses': bccEmailRecipientList
                    },
                    ReplyToAddresses=replyToEmail,
                    FeedbackForwardingEmailAddress=feedbackForwardingEmailAddress,
                    FeedbackForwardingEmailAddressIdentityArn=feedbackForwardingEmailAddressIdentityArn,
                    Content={
                        'Simple': {
                            'Subject': {
                                'Data': emailSubject,
                                'Charset': 'UTF-8'
                            },
                            'Body': {
                                'Html': {
                                    'Data': emailBody,
                                    'Charset': 'UTF-8'
                                }
                            }
                        }
                    }
                )
                logger.info(str(response))
                statusMessage = "Email sent successfully"
                logger.info(statusMessage)
                return "SUCCESS"
        except Exception as e:
            raise Exception(e.__str__())