__AUTHOR__ = 'Mrinal Paul (mrinal.paul2@gilead.com)'

"""
   Module Name         :   Common Transformation Library
   Purpose             :   This module will provide functions that can be used to perform some standard transformation

   Last changed on     :   2023-05-02
   Last changed by     :   Mrinal Paul
   Reason for change   :   New Function added
"""
import os,boto3
import sys
import requests
import json
from datetime import date
from dateutil.relativedelta import relativedelta
import re
import sys
import logging
import boto3
import time
from botocore.exceptions import ClientError

from awsglue.context import GlueContext
from pyspark.context import SparkContext
from pyspark.sql.functions import explode,explode_outer,regexp_replace,udf,lit,col,when
from pyspark.sql.types import StructField,StringType,IntegerType,StructType,DoubleType,LongType,BooleanType,TimestampType,DecimalType,DateType


sc = SparkContext.getOrCreate()
glueContext = GlueContext(sc)
logger = glueContext.get_logger()

class commonTransformation():
    def __init__(self):
        pass
    # Get column list and data type of DF
    def getColumnDataType(self,inpDF):
        try:
            columnDataType = []
            for columnName,dataType in inpDF.dtypes:
                columnDataType.append(
                    {
                        "name": columnName,
                        "data_type": dataType
                    }
                )
            return columnDataType
        except Exception as e:
            logger.error("Error: " + e.__str__())
            raise Exception(e.__str__())
    # Get column list and data type of DF
    def hederNameStandardization(self,inpDF):
        try:
            for columnName in inpDF.columns:
                # Remove Space
                inpDF = inpDF.withColumnRenamed(columnName, re.sub(r'[^a-zA-Z0-9_#]', '_', columnName))
            return inpDF
        except Exception as e:
            logger.error("Error: " + e.__str__())
            raise Exception(e.__str__())
    def createSchema(self,columnList):
        try:
            fieldList = []
            for columnName,dataType in columnList.items():
                if dataType.lower() == "string" or dataType.lower() == "str":
                    fieldList.append(StructField(columnName,StringType(),True))
                elif dataType.lower() == "integer" or dataType.lower() == "int":
                    fieldList.append(StructField(columnName,IntegerType(),True))
                elif dataType.lower() == "double":
                    fieldList.append(StructField(columnName,DoubleType(),True))
                elif dataType.lower() == "decimal":
                    fieldList.append(StructField(columnName,DecimalType(30,2),True))
                elif dataType.lower() == "long":
                    fieldList.append(StructField(columnName,LongType(),True))
                elif dataType.lower() == "boolean":
                    fieldList.append(StructField(columnName,BooleanType(),True))
                elif dataType.lower() == "timestamp":
                    fieldList.append(StructField(columnName,TimestampType(),True))
                elif dataType.lower() == "date":
                    fieldList.append(StructField(columnName,DateType(),True))
            schema = StructType(fieldList)
            return schema
        except Exception as e:
            raise Exception(e.__str__())