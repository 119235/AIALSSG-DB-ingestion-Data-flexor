__AUTHOR__ = 'Mrinal Paul (mrinal.paul2@gilead.com)'

"""
   Module Name         :   Reprocess Already Ingested File Module
   Purpose             :   This Module is used for Clean-Up Activity to Re-Process Already Ingested File

   Last changed on     :   2023-05-02
   Last changed by     :   Mrinal Paul
   Reason for change   :   New Function added
"""
import boto3
from datetime import datetime
from botocore.exceptions import ClientError

from awsglue.context import GlueContext
from pyspark.context import SparkContext
from pyspark.sql.functions import explode,explode_outer,regexp_replace,udf,lit,col,when
import base64
import json
import environmentParams as environmentParams
from DataFlexor import s3Functions

sc = SparkContext.getOrCreate()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
logger = glueContext.get_logger()

class reProcessIngestedFile:
    def __init__(self,env):
        self.env = env
        self.s3Obj = s3Functions()

    def readReProcessMasterFile(self,fileLocationKey):
        try:
            msg= "Reading Re-Process Master File: s3://" + environmentParams.RAW_S3_BUCKET.format(self.env) + "/" + fileLocationKey
            logger.info(msg)
            reProcessMaster = self.s3Obj.getFileContent(environmentParams.RAW_S3_BUCKET.format(self.env),fileLocationKey).read().decode('utf-8')
            reProcessMaster = json.loads(reProcessMaster)
            return reProcessMaster
        except Exception as e:
            logger.error("Error: " + e.__str__())
            return False
    def ingestionTableCleanup(self,targetSchema,targetTableName,targetTableBucket,targetTablePrefix,listOfFileToBeReProcessed):
        try:
            # Prepare String for Where Clause
            listOfFileToBeReProcessedNew = []
            if type(listOfFileToBeReProcessed) == list:
                inCond = "('"
                for file in listOfFileToBeReProcessed:
                    inCond = inCond + file + "','"
                inCond = inCond.rstrip("'").rstrip(",")+")"
                query = "SELECT DISTINCT execution_date, execution_cycle_id, source_file_name FROM {}.{} WHERE source_file_name IN {}".format(targetSchema,targetTableName,inCond)
            elif listOfFileToBeReProcessed.lower() == "all":
                query = "SELECT DISTINCT execution_date, execution_cycle_id, source_file_name FROM {}.{}".format(targetSchema,targetTableName)
            msg = "Re-Processing Query: " + query
            logger.info(msg)
            rePrecessList = spark.sql(query)
            if type(listOfFileToBeReProcessed) == list and rePrecessList.count() == 0:
                for file in listOfFileToBeReProcessed:
                    listOfFileToBeReProcessedNew.append(file)
            for row in rePrecessList.rdd.toLocalIterator():
                cleanUpPrefix = targetTablePrefix + "execution_date=" + row["execution_date"] + "/execution_cycle_id=" + row["execution_cycle_id"] + "/" + "source_file_name=" + row["source_file_name"] + "/"
                listOfFileToBeReProcessedNew.append(row["source_file_name"])
                # Clean Up
                self.s3Obj.cleanUpS3(targetTableBucket,cleanUpPrefix)
            return listOfFileToBeReProcessedNew
        except Exception as e:
            logger.error("Error: " + e.__str__())
            raise Exception(e.__str__())
    def prepareForReProcessing(self,fileLocationKey,datsetName,targetSchema,targetTableName,targetTableBucket,targetTablePrefix,executionDate):
        try:
            reProcessMaster = self.readReProcessMasterFile(fileLocationKey)
            if reProcessMaster != False:
                try:
                    listOfFileToBeReProcessed = reProcessMaster.get(executionDate)[datsetName]['file_name']
                    if len(listOfFileToBeReProcessed) == 0:
                        logger.error("No Files Available for Re-Processing")
                    else:
                        listOfFileToBeReProcessed = self.ingestionTableCleanup(targetSchema,targetTableName,targetTableBucket,targetTablePrefix,listOfFileToBeReProcessed)
                        if type(reProcessMaster.get(executionDate)[datsetName]['file_name']) != list and len(listOfFileToBeReProcessed) == 0:
                            if reProcessMaster.get(executionDate)[datsetName]['file_name'].lower() == "all":
                                listOfFileToBeReProcessed = "all"
                except Exception as e:
                    logger.error("No Files Available for Re-Processing")
                    listOfFileToBeReProcessed = []
            else:
                logger.error("The specified key does not exist")
                listOfFileToBeReProcessed = []
            return listOfFileToBeReProcessed
        except Exception as e:
            logger.error("Error: " + e.__str__())
            raise Exception(e.__str__())