"""
Author
Module Name         :   Common Library
Purpose             :   This Module will trigger Notification to MA stakeholder once
Input Parameters    :
Output              :   JSON/Bool
Predecessor module  :   NA
Successor module    :   NA
Pre-requisites      :   NA
Last changed on     :   2023-05-02
Last changed by     :   Mrinal Paul
Reason for change   :   New Function added
"""
import sys
from datetime import datetime,timedelta
import sys
import boto3
import math
from DataFlexor import notification,secretManager
from pyspark.context import SparkContext
from pyspark.sql.functions import *
from awsglue.context import GlueContext

sc = SparkContext.getOrCreate()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
logger = glueContext.get_logger()

class sendNotification:
    def __init__(self):
        self.today = datetime.now()
    def generate_email_body(self,datasetName,appName,schemaName,tableName,excutionCycleId,executionDate,processName=""):
        try:
            html = '''<head>
            <style>
            .style0
                {mso-number-format:General;
                text-align:general;
                vertical-align:bottom;
                white-space:nowrap;
                mso-rotate:0;
                mso-background-source:auto;
                mso-pattern:auto;
                color:black;
                font-size:11.0pt;
                font-weight:400;
                font-style:normal;
                text-decoration:none;
                font-family:Calibri, sans-serif;
                mso-font-charset:0;
                border:none;
                mso-protection:locked visible;
                mso-style-name:Normal;
                mso-style-id:0;}
            td
                {mso-style-parent:style0;
                padding-top:1px;
                padding-right:1px;
                padding-left:1px;
                mso-ignore:padding;
                color:black;
                font-size:11.0pt;
                font-weight:400;
                font-style:normal;
                text-decoration:none;
                font-family:Calibri, sans-serif;
                mso-font-charset:0;
                mso-number-format:General;
                text-align:general;
                vertical-align:bottom;
                border:none;
                mso-background-source:auto;
                mso-pattern:auto;
                mso-protection:locked visible;
                white-space:nowrap;
                mso-rotate:0;}
            .even {
                mso-style-parent:style0;
                color:black;
                text-align:center;
                vertical-align:middle;
                background:#B7DEE8;
                mso-pattern:black none;
                white-space:normal;
            }
            .odd {
            mso-style-parent:style0;
                color:black;
                text-align:center;
                vertical-align:middle;
                background:#DAEEF3;
                mso-pattern:black none;
                white-space:normal;
            }
            tr th {
                mso-style-parent:style0;
                color:white;
                text-align:center;
                vertical-align:middle;
                background:#70AD47;
                mso-pattern:black none;
                white-space:normal;
            }
            </style>
            </head>
            <body link="#0563C1" vlink="#954F72" lang=EN-US style='tab-interval:.5in; word-wrap:break-word'><span></br>Hi All,</br></br>Please find the Pre-Ingstion DQM Details of Dataset "'''+datasetName+'''" for the ''' + executionDate + ''' run.
            <table border=0 cellpadding=0 cellspacing=0 width=3800 style='border-collapse: collapse;table-layout:fixed;width:2500pt;mso-padding-bottom-alt:0in; mso-padding-left-alt:0in;mso-padding-right-alt:0in;mso-padding-top-alt:0in; mso-yfti-tbllook:1184'> <tr>
            <th height=58 class=xl65 width=65 style='height:43.5pt;width:49pt;padding-bottom: 0in;padding-top:.75pt'>Sr.</th>
            <th class=xl65 width=165 style='width:124pt;padding-bottom:0in;padding-top: .75pt'>File Name</th>
            <th class=xl65 width=165 style='width:124pt;padding-bottom:0in;padding-top: .75pt'>File Type</th>
            <th class=xl65 width=165 style='width:124pt;padding-bottom:0in;padding-top: .75pt'>Ingested Record Count</th>
            <th class=xl65 width=165 style='width:124pt;padding-bottom:0in;padding-top: .75pt'>Execution Datetime</th>
            <th class=xl65 width=165 style='width:124pt;padding-bottom:0in;padding-top: .75pt'>Status</th></tr>
            '''
            query = "SELECT file_name, file_type, record_count,execution_datetime,ingestion_status FROM {}.{} WHERE dataset_name = '{}' AND execution_cycle_id = '{}'".format(schemaName,tableName,datasetName,excutionCycleId)
            msg = "Notification Query: " + query
            logger.info(msg)
            df = spark.sql(query)
            sr = 1
            for row in df.rdd.toLocalIterator():
                if (sr % 2) == 0:
                    clield_class = "even"
                else:
                    clield_class = "odd"
                html += "<tr><td class = "+clield_class+" width=65 style='width:49pt;padding-bottom: 0in;padding-top:.75pt'>"+str(sr)+"</td><td class = " + clield_class + " width=165 style='width:124pt;padding-bottom:0in;padding-top: .75pt'>"+str(row["file_name"])+"</td><td class = " + clield_class + " width=165 style='width:124pt;padding-bottom:0in;padding-top: .75pt'>"+row["file_type"]+"</td><td class = " + clield_class + " width=165 style='width:124pt;padding-bottom:0in;padding-top: .75pt'>"+str(row["record_count"])+"</td><td class = "+clield_class+" width=249 style='width:187pt;padding-bottom:0in;padding-top: .75pt'>"+str(row["execution_datetime"])+"</td><td class = "+clield_class+" width=204 style='width:153pt;padding-bottom:0in;padding-top: .75pt'>"+str(row["ingestion_status"])+"</td></tr>"
                sr = sr + 1
            # Lofic for generating notification from new design ends
            html += "</table></br></br></br>Regards,</br>"+appName.upper()+" Datalake DevOps</body></html>"
            return html
        except Exception as e:
            msg = "Error: " + str(e.__str__())
            logger.error(msg)
            raise e
    def sendNotification(self,datasetName,appName,schemaName,tableName,excutionCycleId,executionDate,processName=""):
        try:
            notificationObj = notification()
            logger.info("Get data from Secretmanager")
            secretManagerObj = secretManager()
            secretName = appName + "_load_notification"
            secret = secretManagerObj.getSecret(secretName)
            emailSender = secret["emailSender"]
            emailSenderArn = secret["emailSenderArn"]
            feedbackForwardingEmailAddress = secret["feedbackForwardingEmailAddress"]
            feedbackForwardingEmailAddressIdentityArn = secret["feedbackForwardingEmailAddressIdentityArn"]
            emailRecipientList = list(secret["emailRecipientList"].split(","))
            ccEmailRecipientList = list(secret["ccEmailRecipientList"].split(","))
            bccEmailRecipientList = list(secret["bccEmailRecipientList"].split(","))
            replyToEmail = list(secret["replyToEmail"].split(","))
            if processName == "":
                emailSubject = appName.upper() + " Dataset "+ datasetName + " Pre-Ingestion DQM Status for " + str(datetime.today().date())
            else:
                emailSubject = appName.upper() + " Dataset "+ datasetName + " Under Process " + processName + " Pre-Ingestion DQM Status for " + str(datetime.today().date())
            emailBody = self.generate_email_body(datasetName,appName,schemaName,tableName,excutionCycleId,executionDate,processName)
            output = notificationObj.sendEmail(emailSubject, emailBody, emailSender,emailSenderArn, feedbackForwardingEmailAddress, feedbackForwardingEmailAddressIdentityArn, emailRecipientList, ccEmailRecipientList,bccEmailRecipientList, replyToEmail)
            if output != "SUCCESS":
                raise Exception(str(output))
            else:
                print("Email Sent")
                return True
        except Exception as e:
            msg = "Error: " + str(e.__str__())
            logger.error(msg)
            raise e