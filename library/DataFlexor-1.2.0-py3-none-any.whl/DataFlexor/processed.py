__AUTHOR__ = 'Mrinal Paul (mrinal.paul2@gilead.com)'

"""
   Module Name         :   Processed Table Module
   Purpose             :   This module is used for Creating/Updating Processed Layer Tale (E.g. HIST/FACT/AGG/RPT)

      How to Invoke       :   call function processedTable(<S3 Prefix of JSON File for Dataset Parameters>,<Final Pyspark Dataframe That need to written to S3 and Refresh Table>)
   Last changed on     :   2023-05-02
   Last changed by     :   Mrinal Paul
   Reason for change   :   Module Created
"""
import boto3
from datetime import datetime
from botocore.exceptions import ClientError

from awsglue.context import GlueContext
from pyspark.context import SparkContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import base64
import json
import environmentParams as environmentParams
from DataFlexor import s3Functions,archive,publishCleanup,GlueTable
from DataFlexorCommonEtl import commonTransformation

sc = SparkContext.getOrCreate()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
logger = glueContext.get_logger()

class processed:
    def __init__(self,env):
        # create S3 Client
        self.s3Obj = s3Functions()
        self.env = env
        self.executionDate = datetime.utcnow().strftime("%Y%m%d")
        self.cycleId = datetime.utcnow().strftime("%Y%m%d%H%M%S%f")
        self.processedTime = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
        self.partitionKeys = [
            {
                'name': "execution_date",
                'data_type': "string"
            },
            {
                'name': "execution_cycle_id",
                'data_type': "string"
            }
        ]
        self.partitionValues = {
            "execution_date": str(self.executionDate),
            "execution_cycle_id": str(self.cycleId)
        }
        self.commonTransformationObj = commonTransformation()
        self.logTableSchema = StructType([
                StructField("dataset_name", StringType(), True),
                StructField("application", StringType(), True),
                StructField("table_location", StringType(), True),
                StructField("table_schema", StringType(), True),
                StructField("table_name", StringType(), True),
                StructField("processed_table_record_count", IntegerType(), True),
                StructField("publish_table_schema", StringType(), True),
                StructField("publish_table_name", StringType(), True),
                StructField("publish_table_record_count", IntegerType(), True),
                StructField("execution_datetime", StringType(), True)
            ])

    def updateGlueTable(self,sourceDataDf,targetSchema,targetTable,tableDescription,finalTableLocation,partitionKeys,partitionValues,archiveFlag=False):
        try:
            # Create/Update Table
            columnList = self.commonTransformationObj.getColumnDataType(sourceDataDf)
            GlueTableObj = GlueTable(targetSchema,targetTable,tableDescription,columnList,finalTableLocation,partitionKeys,partitionValues)
            if archiveFlag == True:
                GlueTableObj.getAndDeletePartitions()
            # Load Partition
            status = GlueTableObj.loadGlueTable()
            if status == True:
                logger.info("Table "+targetTable+" loaded successfully")
        except Exception as e:
            msg = "Error: " + str(e.__str__())
            logger.error(msg)
            raise Exception(e.__str__())
    def updateProcessedLog(self):
        try:
            # Prepare Processed log Datafrate amd table
            processedLogSchema = environmentParams.LOG_SCHEMA
            logTable = "processed_table_log_"+self.applicationName
            logTable = logTable.replace("-","_")

            processedLogList = [(self.datasetName,self.applicationName,self.processedTablePath,self.processedSchema,self.processedTableName,self.recordCount,self.publishSchema,self.publishTable,self.publishRecordCount,self.processedTime)]

            processedLogDf = spark.createDataFrame(processedLogList, schema=self.logTableSchema)
            # Write Log to S3 location
            logTablePath = "s3://" + environmentParams.PROCESSED_S3_BUCKET.format(self.env) + "/" + self.applicationName + "/processed_log/" + logTable + "/"
            logTablePathFinal = logTablePath + "execution_date=" + self.executionDate + "/execution_cycle_id=" + str(self.cycleId) + "/"
            processedLogDf.replace("null","").write.mode("overwrite").option("multiline",True).option("escape","\"").option("self.encoding", "utf-8").parquet(logTablePathFinal)
            self.updateGlueTable(processedLogDf,processedLogSchema,logTable,'',logTablePath,self.partitionKeys,self.partitionValues)
            msg = "Updated Log Table: " + logTable
            logger.info(msg)
        except Exception as e:
            msg = "Error: " + str(e.__str__())
            logger.error(msg)
            raise Exception(e.__str__())

    def createTablePath(self):
        try:
            partitionKeys = self.partitionKeys
            partitionValues = self.partitionValues
            tableSubPath = ""
            for k in partitionKeys:
                if tableSubPath == "":
                    tableSubPath = k["name"] + "=" + partitionValues[k["name"]] + "/"
                else:
                    tableSubPath = tableSubPath + k["name"] + "=" + partitionValues[k["name"]] + "/"
            return tableSubPath,partitionKeys,partitionValues
        except Exception as e:
            msg = "Error: " + str(e.__str__())
            logger.error(msg)
            raise Exception(e.__str__())
    def loadProcessedTable(self,resultDf):
        try:
            # Prepare Final S3 Location
            tableSubPath,partitionKeys,partitionValues = self.createTablePath()
            finalTableLocation = self.processedTablePath + tableSubPath

            msg = "Started Loading Processed Table"
            logger.info(msg)
            # Write Source DF to S3 Target Location
            resultDf.replace("null","").write.mode("overwrite").option("multiline",True).option("escape","\"").option("self.encoding", "utf-8").parquet(finalTableLocation)
            if self.archiveFlag == "Y":
                archiveFlag = True
            else:
                archiveFlag = False
            self.updateGlueTable(resultDf,self.processedSchema,self.processedTableName,'',self.processedTablePath,partitionKeys,partitionValues,archiveFlag)
            msg = self.processedTableName + " Table Loaded Successfully"
            logger.info(msg)
            count = resultDf.count()
            return count
        except Exception as e:
            msg = "Error: " + str(e.__str__())
            logger.error(msg)
            raise Exception(e.__str__())
    def loadPublishTable(self,resultDf):
        try:
            # Prepare Final S3 Location
            tableSubPath,partitionKeys,partitionValues = self.createTablePath()
            finalTableLocation = self.publishTablePath + tableSubPath

            msg = "Started Loading Processed Table"
            logger.info(msg)
            # Write Source DF to S3 Target Location
            resultDf.replace("null","").write.mode("overwrite").option("multiline",True).option("escape","\"").option("self.encoding", "utf-8").parquet(finalTableLocation)
            if self.archiveFlag == "Y":
                archiveFlag = True
            else:
                archiveFlag = False
            self.updateGlueTable(resultDf,self.publishSchema,self.publishTable,'',self.publishTablePath,partitionKeys,partitionValues,archiveFlag)
            msg = self.publishTable + " Table Loaded Successfully"
            logger.info(msg)
            count = resultDf.count()
            return count
        except Exception as e:
            msg = "Error: " + str(e.__str__())
            logger.error(msg)
            raise Exception(e.__str__())
    def executeSqlScript(self,sqlScriptPath):
        try:
            # Prepare Final S3 Location
            if sqlScriptPath.startswith("s3://"):
                sqlScriptPath = sqlScriptPath.split("/")
                sqlScriptPathBucket = sqlScriptPath[0]
                sqlScriptPath = "/".join(sqlScriptPath[1:])
            else:
                sqlScriptPathBucket = environmentParams.PLATFORM_ARTIFACTS_S3_BUCKET.format(self.env)
                sqlScriptPath = sqlScriptPath.lstrip("/").split("/")
                if sqlScriptPath[0] == environmentParams.APPLICATION_NAME:
                    sqlScriptPath = "/".join(sqlScriptPath)
                else:
                    sqlScriptPath = environmentParams.APPLICATION_NAME + "/" + "/".join(sqlScriptPath)
            rawQuery = self.s3Obj.getFileContent(sqlScriptPathBucket,sqlScriptPath)
            if rawQuery == None or rawQuery == "":
                msg = "The SQL Script is Blank: s3://" + sqlScriptPathBucket + sqlScriptPath
                logger.error(msg)
                raise Exception(msg)
            query = ""
            for line in rawQuery.iter_lines():
                line = line.decode('utf-8')
                query = query + line.replace("\r","") + "\n"
            msg = "Query Fetched from SQL Script: " + str(query)
            logger.info(msg)
            msg = "Executin Query: " + str(query)
            logger.info(msg)
            resultDf = spark.sql(query)
            msg = "Query Executed"
            logger.info(msg)
            return resultDf
        except Exception as e:
            msg = "Error: " + str(e.__str__())
            logger.error(msg)
            raise Exception(e.__str__())
    def processedTable(self,datasetMasterKey,resultDf):
        try:
            # Read Processed Object Json Config
            if datasetMasterKey.endswith("/"):
                msg = "datasetMasterKey should not be directory"
                logger.error(msg)
                raise Exception(msg)
            if datasetMasterKey.startswith('s3://'):
                datasetMasterKey = datasetMasterKey.lstrip("s3://").split("/")
                datasetMasterBucket = datasetMasterKey[0]
                datasetMasterKey = "/".join(datasetMasterKey[1:])
            else:
                datasetMasterBucket = environmentParams.PLATFORM_ARTIFACTS_S3_BUCKET.format(self.env)
                datasetMasterKey = datasetMasterKey.lstrip("/").split("/")
                if datasetMasterKey[0] == environmentParams.APPLICATION_NAME:
                    datasetMasterKey = "/".join(datasetMasterKey)
                else:
                    datasetMasterKey = environmentParams.APPLICATION_NAME + "/" + "/".join(datasetMasterKey)

            try:
                datasetMaster = self.s3Obj.getFileContent(datasetMasterBucket,datasetMasterKey).read().decode('utf-8')
                datasetMaster = json.loads(datasetMaster)
            except Exception as e:
                msg = "Error: " + str(e.__str__()) + "s3://" + datasetMasterKey + "/" + datasetMasterKey
                logger.error(msg)
                raise Exception(e.__str__())

            self.datasetName = datasetMaster.get("dataset_name")
            active = datasetMaster.get("active")
            if active.upper() == "N":
                msg = "Skipping the Dataset as The Dataset is not Active for Processed"
                logger.warn(msg)
                return True

            self.applicationName = environmentParams.APPLICATION_NAME.lower()

            match datasetMaster.get("processed_location_bucket").upper():
                case "RAW_S3_BUCKET":
                    self.processedLocationBucket = environmentParams.RAW_S3_BUCKET.format(self.env)
                case "SANDBOX_S3_BUCKET":
                    self.processedLocationBucket = environmentParams.SANDBOX_S3_BUCKET.format(self.env)
                case "PROCESSED_S3_BUCKET":
                    self.processedLocationBucket = environmentParams.PROCESSED_S3_BUCKET.format(self.env)
                case "CURATED_S3_BUCKET":
                    self.processedLocationBucket = environmentParams.CURATED_S3_BUCKET.format(self.env)
                case _:
                    self.processedLocationBucket = datasetMaster.get("processed_location_bucket").lstrip("s3://").rstrip("/")

            self.processedLocationPrefix = datasetMaster.get("processed_location_prefix").strip("/") + "/"
            self.processedTablePath = "s3://" + self.processedLocationBucket + "/" + self.processedLocationPrefix

            match datasetMaster.get("processed_schema").upper():
                case "STAGING_SCHEMA":
                    self.processedSchema = environmentParams.STAGING_SCHEMA
                case "PROCESSED_SCHEMA":
                    self.processedSchema = environmentParams.PROCESSED_SCHEMA
                case "REPORTING_SCHEMA":
                    self.processedSchema = environmentParams.REPORTING_SCHEMA
                case "PUBLISH_SCHEMA":
                    self.processedSchema = environmentParams.PUBLISH_SCHEMA
                case _:
                    self.processedSchema = datasetMaster.get("processed_schema")

            self.processedTableName = datasetMaster.get("processed_table")
            if len(self.processedTableName) > 40:
                msg = "Maximum Length of Table Name alowed is 40 Character"
                logger.info(msg)
                raise Exception(msg)
            try:
                self.archiveFlag = datasetMaster.get("archive").upper()
            except Exception as e:
                self.archiveFlag = "N"

            publishFlag = datasetMaster.get("publish_flag").upper()

            if resultDf == None:
                logger.info("Result Dataframe is Empty!!! Starting process for Executing SQL Script")
                try:
                    # If the resultDf is not passed search for SQL file
                    sqlScriptPath = datasetMaster.get("sql_script_path")
                    if sqlScriptPath == None or sqlScriptPath == "":
                        msg = "No SQL Script Found"
                        logger.error(msg)
                        raise Exception(msg)
                    elif not sqlScriptPath.endswith(".sql"):
                        msg = "SQL Script Path Should be a SQL (*.sql) file"
                        logger.error(msg)
                        raise Exception(msg)
                    resultDf = self.executeSqlScript(sqlScriptPath)
                except Exception as e:
                    logger.error("Error: " + e.__str__())
                    raise Exception(e.__str__())
            self.recordCount = self.loadProcessedTable(resultDf)
            msg = "Updated Processed Table: " + self.processedTableName
            logger.info(msg)
            msg = "Total Records Loaded: " + str(self.recordCount)
            logger.info(msg)

            # Check publish table flag
            if publishFlag == "Y":
                match datasetMaster.get("publish_schema").upper():
                    case "STAGING_SCHEMA":
                        self.publishSchema = environmentParams.STAGING_SCHEMA
                    case "PROCESSED_SCHEMA":
                        self.publishSchema = environmentParams.PROCESSED_SCHEMA
                    case "REPORTING_SCHEMA":
                        self.publishSchema = environmentParams.REPORTING_SCHEMA
                    case "PUBLISH_SCHEMA":
                        self.publishSchema = environmentParams.PUBLISH_SCHEMA
                    case _:
                        self.publishSchema = datasetMaster.get("publish_schema")

                self.publishTable = datasetMaster.get("publish_table")
                if len(self.publishTable) > 40:
                    msg = "Maximum Length of Table Name alowed is 40 Character"
                    logger.info(msg)
                    raise Exception(msg)

                match datasetMaster.get("publish_location_bucket").upper():
                    case "PUBLISH_S3_BUCKET":
                        self.publishLocationBucket = environmentParams.PUBLISH_S3_BUCKET.format(self.env)
                    case "RAW_S3_BUCKET":
                        self.publishLocationBucket = environmentParams.RAW_S3_BUCKET.format(self.env)
                    case "SANDBOX_S3_BUCKET":
                        self.publishLocationBucket = environmentParams.SANDBOX_S3_BUCKET.format(self.env)
                    case "PROCESSED_S3_BUCKET":
                        self.publishLocationBucket = environmentParams.PROCESSED_S3_BUCKET.format(self.env)
                    case "CURATED_S3_BUCKET":
                        self.publishLocationBucket = environmentParams.CURATED_S3_BUCKET.format(self.env)
                    case _:
                        self.publishLocationBucket = datasetMaster.get("publish_location_bucket").lstrip("s3://").rstrip("/")
                self.publishLocationPrefix = datasetMaster.get("publish_location_prefix").strip("/") + "/"
                self.publishTablePath = "s3://" + self.publishLocationBucket + "/" + self.publishLocationPrefix
                msg = "Loading Publish Table"
                logger.info(msg)
                self.publishRecordCount = self.loadPublishTable(resultDf)
                publishCleanupObj = publishCleanup()
                publishCleanupObj.publishCleanup(self.publishLocationBucket,self.publishLocationPrefix,self.executionDate,self.cycleId)
                msg = "Total Records Loaded in Publish Table: " + str(self.publishRecordCount)
                logger.info(msg)
            else:
                self.publishSchema = None
                self.publishTable = None
                self.publishRecordCount = 0

            msg = "Updating Log Table"
            logger.info(msg)
            self.updateProcessedLog()

            # Start Archival Process
            if self.archiveFlag == "Y":
                archiveBucket = datasetMaster.get("archive_location_bucket")
                match archiveBucket.upper():
                    case "RAW_S3_BUCKET":
                        archiveBucket = environmentParams.RAW_S3_BUCKET.format(self.env)
                    case "SANDBOX_S3_BUCKET":
                        archiveBucket = environmentParams.SANDBOX_S3_BUCKET.format(self.env)
                    case "PROCESSED_S3_BUCKET":
                        archiveBucket = environmentParams.PROCESSED_S3_BUCKET.format(self.env)
                    case "CURATED_S3_BUCKET":
                        archiveBucket = environmentParams.CURATED_S3_BUCKET.format(self.env)
                    case _:
                        archiveBucket = archiveBucket.lstrip("s3://").rstrip("/")
                archivePrefix = datasetMaster.get("archive_location_prefix")
                archiveObj = archive()
                archiveObj.archiveProcessedTableData(self.processedLocationBucket,self.processedLocationPrefix+"execution_date="+self.executionDate+"/",self.cycleId,archiveBucket,archivePrefix)
                msg = "Archived Previous Run Data"
                logger.info(msg)
            else:
                msg = "Skipping Archival Process for " + self.processedTableName + " as the load type is not FULL"
                logger.info(msg)
            # Integration of POST Ingestion DQMs
            try:
                dqmConfigFiles = datasetMaster.get("dqm_config_s3_key")
            except Exception as e:
                logger.error("Error: " + e.__str__())
                msg = "DQM JSON Config file missing, hence skipping the process"
                logger.info(msg)
                dqmConfigFiles = None

            msg = "DQM JSON Config file location: {}".format(str(dqmConfigFiles))
            logger.info(msg)

            if dqmConfigFiles != None and dqmConfigFiles != "":
                from DataGuardian import executeDqm
                executeDqmObj = executeDqm(dqmConfigFiles,self.env)
                sourcePath = "s3://{}/{}/{}/{}/".format(self.processedLocationBucket,self.processedLocationPrefix,"execution_date="+str(self.executionDate),"execution_cycle_id="+self.cycleId)
                executeDqmObj.processDQM(self.datasetName,sourcePath)
            else:
                msg = "DQM JSON Config file missing, hence skipping the process"
                logger.info(msg)
                return True
        except Exception as e:
            logger.error("Error: " + e.__str__())
            raise Exception(e.__str__())