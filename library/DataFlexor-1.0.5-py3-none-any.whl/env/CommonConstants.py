# S3 Variables
RAW_S3_BUCKET = 'gilead-commercial-dev-us-west-2-nba-raw'
SANDBOX_S3_BUCKET = 'gilead-commercial-dev-us-west-2-sandbox'
PROCESSED_S3_BUCKET = 'gilead-commercial-dev-us-west-2-nba-processed'
PLATFORM_ARTIFACTS_S3_BUCKET = 'gilead-commercial-dev-us-west-2-platform-artifacts'
LOG_S3_BUCKET = 'gilead-commercial-dev-us-west-2-logs'
CODE_ARTIFACTS_S3_BUCKET = 'gilead-commercial-dev-us-west-2-code-artifacts'

# Other Variables
ENV_NAME = "DEV"