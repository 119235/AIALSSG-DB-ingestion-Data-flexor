"""
Author
Module Name         :   Common Library
Purpose             :   This Module will trigger Notification to MA stakeholder once
Input Parameters    :
Output              :   JSON/Bool
Predecessor module  :   NA
Successor module    :   NA
Pre-requisites      :   NA
Last changed on     :   2023-05-02
Last changed by     :   Mrinal Paul
Reason for change   :   New Function added
"""
import sys
from awsglue.utils import getResolvedOptions
from datetime import datetime,timedelta
import sys
import boto3
import math
from DataFlexor import notification,secretManager
from pyspark.context import SparkContext
from pyspark.sql.functions import explode,explode_outer,regexp_replace,udf,lit,col,when,unix_timestamp,to_timestamp,date_format
from awsglue.context import GlueContext
import environmentParams as environmentParams

sc = SparkContext.getOrCreate()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
logger = glueContext.get_logger()

class sendNotification:
    def __init__(self):
        self.today = datetime.now()
        self.args = getResolvedOptions(sys.argv, ["env"])
        self.env = self.args['env']
    def generate_email_body(self,datasetName,appName,executionCycleId,processName):
        try:
            html = '''<head>
            <style>
            .style0
                {mso-number-format:General;
                text-align:general;
                vertical-align:bottom;
                white-space:nowrap;
                mso-rotate:0;
                mso-background-source:auto;
                mso-pattern:auto;
                color:black;
                font-size:11.0pt;
                font-weight:400;
                font-style:normal;
                text-decoration:none;
                font-family:Calibri, sans-serif;
                mso-font-charset:0;
                border:none;
                mso-protection:locked visible;
                mso-style-name:Normal;
                mso-style-id:0;}
            td
                {mso-style-parent:style0;
                padding-top:1px;
                padding-right:1px;
                padding-left:1px;
                mso-ignore:padding;
                color:black;
                font-size:11.0pt;
                font-weight:400;
                font-style:normal;
                text-decoration:none;
                font-family:Calibri, sans-serif;
                mso-font-charset:0;
                mso-number-format:General;
                text-align:general;
                vertical-align:bottom;
                border:none;
                mso-background-source:auto;
                mso-pattern:auto;
                mso-protection:locked visible;
                white-space:nowrap;
                mso-rotate:0;}
            .even {
                mso-style-parent:style0;
                color:black;
                text-align:center;
                vertical-align:middle;
                background:#B7DEE8;
                mso-pattern:black none;
                white-space:normal;
            }
            .odd {
            mso-style-parent:style0;
                color:black;
                text-align:center;
                vertical-align:middle;
                background:#DAEEF3;
                mso-pattern:black none;
                white-space:normal;
            }
            tr th {
                mso-style-parent:style0;
                color:white;
                text-align:center;
                vertical-align:middle;
                background:#70AD47;
                mso-pattern:black none;
                white-space:normal;
            }
            </style>
            </head>
            <body link="#0563C1" vlink="#954F72" lang=EN-US style='tab-interval:.5in; word-wrap:break-word'><span></br>Hi All,</br></br>Please find the Pre-Ingstion DQM Details of Dataset "'''+datasetName+'''" for the ''' + str(str(datetime.utcnow().strftime("%Y-%m-%d"))) + ''' run.</br></br></br>
            <table border=0 cellpadding=0 cellspacing=0 width=3800 style='border-collapse: collapse;table-layout:fixed;width:2500pt;mso-padding-bottom-alt:0in; mso-padding-left-alt:0in;mso-padding-right-alt:0in;mso-padding-top-alt:0in; mso-yfti-tbllook:1184'> <tr>
            <th height=58 class=xl65 width=65 style='height:43.5pt;width:49pt;padding-bottom: 0in;padding-top:.75pt'>Sr.</th>
            <th class=xl65 width=165 style='width:124pt;padding-bottom:0in;padding-top: .75pt'>File Name</th>
            <th class=xl65 width=165 style='width:124pt;padding-bottom:0in;padding-top: .75pt'>QC ID</th>
            <th class=xl65 width=165 style='width:124pt;padding-bottom:0in;padding-top: .75pt'>QC Message</th>
            <th class=xl65 width=165 style='width:124pt;padding-bottom:0in;padding-top: .75pt'>Source Record Count</th>
            <th class=xl65 width=165 style='width:124pt;padding-bottom:0in;padding-top: .75pt'>Total Records Ingested</th>
            <th class=xl65 width=165 style='width:124pt;padding-bottom:0in;padding-top: .75pt'>Total Valid Records</th>
            <th class=xl65 width=165 style='width:124pt;padding-bottom:0in;padding-top: .75pt'>Total Error Records</th>
            <th class=xl65 width=165 style='width:124pt;padding-bottom:0in;padding-top: .75pt'>Execution Datetime</th>
            <th class=xl65 width=165 style='width:124pt;padding-bottom:0in;padding-top: .75pt'>Status</th></tr>
            '''
            logTableName = "log_dqm_dg_{}_{}".format(environmentParams.APPLICATION_NAME.lower().replace("-","_"),"ing")
            fileLogTable = "file_log_"+environmentParams.APPLICATION_NAME.lower()
            query = "SELECT file_name, total_record_count, validated_record_count, errored_record_count,file_name,record_count, execution_datetime, ingestion_status, qc_id, message FROM (SELECT dataset_name, qc_id, pre_ingestion_dqm_file, total_record_count, validated_record_count, errored_record_count, message FROM `{}`.{} WHERE dataset_name = '{}' AND execution_cycle_id = '{}') A LEFT JOIN (SELECT dataset_name, file_name,record_count, execution_datetime, ingestion_status FROM `{}`.{} WHERE dataset_name = '{}' AND execution_cycle_id = '{}') B ON A.dataset_name = B.dataset_name AND A.pre_ingestion_dqm_file = B.file_name ORDER BY B.file_name,qc_id".format(environmentParams.LOG_SCHEMA.replace("`",""),logTableName,datasetName,executionCycleId,environmentParams.LOG_SCHEMA.replace("`",""),fileLogTable,datasetName,executionCycleId)
            msg = "Notification Query: " + query
            logger.info(msg)
            df = spark.sql(query)
            sr = 1
            for row in df.rdd.toLocalIterator():
                if (sr % 2) == 0:
                    clield_class = "even"
                else:
                    clield_class = "odd"
                html += '''<tr><td class = '''+clield_class+''' width=65 style='width:49pt;padding-bottom: 0in;padding-top:.75pt'>'''+str(sr)+'''</td>
                <td class = ''' + clield_class + ''' width=165 style='width:124pt;padding-bottom:0in;padding-top: .75pt'>'''+str(row["file_name"])+'''</td>
                <td class = ''' + clield_class + ''' width=165 style='width:124pt;padding-bottom:0in;padding-top: .75pt'>'''+str(row["qc_id"])+'''</td>
                <td class = ''' + clield_class + ''' width=165 style='width:124pt;padding-bottom:0in;padding-top: .75pt'>'''+str(row["message"])+'''</td>
                <td class = ''' + clield_class + ''' width=165 style='width:124pt;padding-bottom:0in;padding-top: .75pt'>'''+str(row["total_record_count"])+'''</td>
                <td class = ''' + clield_class + ''' width=165 style='width:124pt;padding-bottom:0in;padding-top: .75pt'>'''+str(row["record_count"])+'''</td>
                <td class = ''' + clield_class + ''' width=165 style='width:124pt;padding-bottom:0in;padding-top: .75pt'>'''+str(row["validated_record_count"])+'''</td>
                <td class = ''' + clield_class + ''' width=165 style='width:124pt;padding-bottom:0in;padding-top: .75pt'>'''+str(row["errored_record_count"])+'''</td>
                <td class = '''+clield_class+''' width=249 style='width:187pt;padding-bottom:0in;padding-top: .75pt'>'''+str(row["execution_datetime"])+'''</td>
                <td class = '''+clield_class+''' width=204 style='width:153pt;padding-bottom:0in;padding-top: .75pt'>'''+str(row["ingestion_status"])+'''</td></tr>'''
                sr = sr + 1
            # Lofic for generating notification from new design ends
            html += "</table></br></br></br>Regards,</br>"+appName.upper()+" DevOps</body></html>"
            return html
        except Exception as e:
            msg = "Error: " + str(e.__str__())
            logger.error(msg)
            raise e
    def sendNotification(self,datasetName,executionCycleId,processName="",workSpaceName=""):
        try:
            appName = environmentParams.APPLICATION_NAME
            notificationObj = notification()
            logger.info("Get data from Secretmanager")
            secretManagerObj = secretManager()
            secretName = workSpaceName+"/"+appName + "_load_notification"
            secret = secretManagerObj.getSecret(secretName)
            emailSender = secret["emailSender"]
            emailRecipientList = secret["emailRecipientList"]
            ccEmailRecipientList = secret["ccEmailRecipientList"]
            bccEmailRecipientList = secret["bccEmailRecipientList"]
            if processName == "":
                emailSubject = "(" + self.env.upper() + ") " + appName.upper() + " Dataset "+ datasetName + " Pre-Ingestion DQM Status for " + str(datetime.today().date())
            else:
                emailSubject = "(" + self.env.upper() + ") " + appName.upper() + " Dataset "+ datasetName + " Under Process " + processName + " Pre-Ingestion DQM Status for " + str(datetime.today().date())
            emailBody = self.generate_email_body(datasetName,appName,executionCycleId,processName)
            output = notificationObj.sendEmail(emailSubject, emailBody, emailSender, str(emailRecipientList), str(ccEmailRecipientList),str(bccEmailRecipientList))
            if output != True:
                raise Exception(str(output))
            else:
                logger.info("Email Sent")
                return True
        except Exception as e:
            msg = "Error: " + str(e.__str__())
            logger.error(msg)